var express = require('express');
var router = express.Router();

var Web3 = require('web3');
// 引入ethereumjs-tx
var Tx = require('ethereumjs-tx');

var router = express.Router();
var app = express();
const bip39 = require('bip39');
const bip32 = require('bip32');
const bitcoin = require('bitcoinjs-lib');

var hdkey = require('ethereumjs-wallet/hdkey')
var util = require('ethereumjs-util')

// 补齐64位，不够前面用0补齐
function addPreZero(num){
    var t = (num+'').length,
        s = '';
    for(var i=0; i<64-t; i++){
        s += '0';
    }
    return s+num;
}


if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    // web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
    web3 = new Web3(new Web3.providers.HttpProvider("http://140.143.143.211:8545"));
}

/* GET home page. */
app.get('/balance', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var content = req.query.content;


    // 定义合约abi
    var contractAbi = [{"constant":true,"inputs":[],"name":"mintingFinished","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"cap","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"unpause","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_amount","type":"uint256"}],"name":"mint","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_value","type":"uint256"}],"name":"burn","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"paused","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_subtractedValue","type":"uint256"}],"name":"decreaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"finishMinting","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"pause","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_addedValue","type":"uint256"}],"name":"increaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"burner","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"amount","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[],"name":"MintFinished","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}];

// 合约地址
    var contractAddress = "0x7FCCF800568747b178c6cBbe4Bf3d147df75ac61";

// 账号
    var currentAccount = content;

    var aaq = 0

  // 查询以太币余额
    web3.eth.getBalance(currentAccount).then(val => {
        res.json({
            "error":0,
            "balance":val
        });
        console.info(`Status switches to fulfilled, and the value is ${val}`);
    });
});
/* GET home page. */
router.get('/balance/token', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var content = req.query.content;
    var contract_address = req.query.contract_address;
    if (content == "" || content == undefined || contract_address == "" || contract_address == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }


    // 定义合约abi
    var contractAbi = [{"constant":true,"inputs":[],"name":"mintingFinished","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"cap","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"unpause","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_amount","type":"uint256"}],"name":"mint","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_value","type":"uint256"}],"name":"burn","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"paused","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_subtractedValue","type":"uint256"}],"name":"decreaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"finishMinting","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"pause","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_addedValue","type":"uint256"}],"name":"increaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"burner","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"amount","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[],"name":"MintFinished","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}];

// 合约地址
    var contractAddress = "0x7FCCF800568747b178c6cBbe4Bf3d147df75ac61";

// 账号
    var currentAccount = content;

    var aaq = 0

    // 查询以太币余额
    web3.eth.getBalance(currentAccount).then(val => {
        res.json({
            "error":0,
            "balance":val
        });
        console.info(`Status switches to fulfilled, and the value is ${val}`);
    });
});
/* GET home page. */
router.get('/transfer', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var currentAccount = req.query.from_address;
    var toaddress = req.query.toaddress;        //转账地址
    var transfer_value = req.query.transfer_value; //转账值


    var private = req.query.privates

    if (currentAccount == "" || currentAccount == undefined || toaddress == "" || toaddress == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }

// 账号
//     var currentAccount = "0x9c90e8DfF5a9Bba0683400d4Cac4c457eaBdb391";

    // 以太币转账
// 先获取当前账号交易的nonce
    web3.eth.getTransactionCount(currentAccount, web3.eth.defaultBlock.pending).then(function(nonce){

        // 获取交易数据
        var txData = {
            // nonce每次++，以免覆盖之前pending中的交易
            nonce: web3.utils.toHex(nonce++),
            // 设置gasLimit和gasPrice
            gasLimit: web3.utils.toHex(99000),
            gasPrice: web3.utils.toHex(10e9),
            // 要转账的哪个账号
            to: toaddress,
            // 从哪个账号转
            from: currentAccount,
            // 0.001 以太币
            // value: web3.utils.toHex(10e14),
            value: web3.utils.toHex(transfer_value * 1000000000000000000),
            data: 'xxxxxxx'
        }

        var tx = new Tx(txData);

        // 引入私钥，并转换为16进制
        const privateKey = new Buffer(private, 'hex');

        // 用私钥签署交易
        tx.sign(privateKey);

        // 序列化
        var serializedTx = tx.serialize().toString('hex');

        web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex'), function(err, hash) {
            if (!err) {
                console.log(hash);
                res.json({
                    "error":0,
                    "content":hash
                });
            } else {
                console.error(err);
                res.json({
                    "error":1,
                    "content":"err"
                });
            }
        });
    });

});
router.get('/transaction', function(req, res, next) {
    // web3.eth.getTransactionReceipt("0x3F5699C087e87ddF72929F54e308c5f7162dF7D3").then(console.log);
    var receipt = web3.eth.getTransactionReceipt('0xedda0274611e6552be8f46cc3677c91215295bb69ffb0360ecd94b05bb16f4e2')
        .then(console.log);
});
router.get('/transfer/token', function(req, res, next) {
    web3.eth.getTransactionCount("0x3F5699C087e87ddF72929F54e308c5f7162dF7D3", web3.eth.defaultBlock.pending).then(function(nonce){

        // 获取交易数据
        var txData = {
            nonce: web3.utils.toHex(nonce++),
            gasLimit: web3.utils.toHex(99000),
            gasPrice: web3.utils.toHex(10e9),
            // 注意这里是代币合约地址
            to: "0x8FfDFFa55B2c5932404C63CB00e1756b621104ce",
            from: "0x3F5699C087e87ddF72929F54e308c5f7162dF7D3",
            // 调用合约转账value这里留空
            value: '0x00',
            // data的组成，由：0x + 要调用的合约方法的function signature + 要传递的方法参数，每个参数都为64位(对transfer来说，第一个是接收人的地址去掉0x，第二个是代币数量的16进制表示，去掉前面0x，然后补齐为64位)
            data: '0x' + 'a9059cbb' + addPreZero('9c90e8DfF5a9Bba0683400d4Cac4c457eaBdb391') + addPreZero(web3.utils.toHex(10000000000000000000).substr(2))
        }

        var tx = new Tx(txData);

        const privateKey = new Buffer('11787318b26ad0b564c7669a636514dc98a9c5f63a822f1d8ae3d22c573f62f1', 'hex');

        tx.sign(privateKey);

        var serializedTx = tx.serialize().toString('hex');

        web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex'), function(err, hash) {
            if (!err) {
                res.json({
                    "error":0,
                    "content":"ok",
                    "hash":hash,
                });
                console.log(hash);
            } else {
                res.json({
                    "error":1,
                    "content":"请重试"
                });
                console.error(err);
            }
        });
    });
});
router.get('/transfer/oec', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var heyueaddress = req.query.contract_address;
    var is_new = req.query.is_new;
    var toaddress = req.query.toaddress;        //转账地址
    var transfer_value = req.query.transfer_value; //转账值
    
    if (is_new == "1"){
        var transfer_value = transfer_value;
    } else{
        var transfer_value = transfer_value * 1000000000000000000; //转账值
    }


    if (heyueaddress == "" || heyueaddress == undefined || toaddress == "" || toaddress == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }
    var fromeaddress = req.query.fromeaddress
    var private = req.query.privates

    web3.eth.getTransactionCount(fromeaddress, web3.eth.defaultBlock.pending).then(function(nonce){

        // 获取交易数据
        var txData = {
            nonce: web3.utils.toHex(nonce++),
            gasLimit: web3.utils.toHex(99000),
            gasPrice: web3.utils.toHex(10e9),
            // 注意这里是代币合约地址
            to: heyueaddress,
            from: fromeaddress,
            // 调用合约转账value这里留空
            value: '0x00',
            // data的组成，由：0x + 要调用的合约方法的function signature + 要传递的方法参数，每个参数都为64位(对transfer来说，第一个是接收人的地址去掉0x，第二个是代币数量的16进制表示，去掉前面0x，然后补齐为64位)
            data: '0x' + 'a9059cbb' + addPreZero(toaddress) + addPreZero(web3.utils.toHex(transfer_value).substr(2))
        }

        var tx = new Tx(txData);

        const privateKey = new Buffer(private, 'hex');

        tx.sign(privateKey);

        var serializedTx = tx.serialize().toString('hex');

        web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex'), function(err, hash) {
            if (!err) {
                res.json({
                    "error":0,
                    "content":"ok",
                    "hash":hash,
                });
                console.log(hash);
            } else {
                res.json({
                    "error":1,
                    "content":err.toString()
                });
                console.error(err.toString());
            }
        });
    });
});

module.exports = router;

var server = app.listen(8080, function () {   //监听端口
  var host = server.address().address
  var port = server.address().port
  console.log('Example app listening at http://%s:%s', host, port);
})
