var express = require('express');
var router = express.Router();

var Web3 = require('web3');

// 引入ethereumjs-tx
var Tx = require('ethereumjs-tx').Transaction;

const bip39 = require('bip39');
const bip32 = require('bip32');
const bitcoin = require('bitcoinjs-lib');

var hdkey = require('ethereumjs-wallet/hdkey')
var util = require('ethereumjs-util')

function hexCharCodeToStr(hexCharCodeStr) {
    var trimedStr = hexCharCodeStr.trim();
    var rawStr =
        trimedStr.substr(0,2).toLowerCase() === "0x"
            ?
            trimedStr.substr(2)
            :
            trimedStr;
    var len = rawStr.length;
    if(len % 2 !== 0) {
        alert("Illegal Format ASCII Code!");
        return "";
    }
    var curCharCode;
    var resultStr = [];
    for(var i = 0; i < len;i = i + 2) {
        curCharCode = parseInt(rawStr.substr(i, 2), 16); // ASCII Code Value
        resultStr.push(String.fromCharCode(curCharCode));
    }
    return resultStr.join("");
}
function string_hex2int(hex) {
    var len = hex.length, a = new Array(len), code;
    for (var i = 0; i < len; i++) {
        code = hex.charCodeAt(i);
        if (48<=code && code < 58) {
            code -= 48;
        } else {
            code = (code & 0xdf) - 65 + 10;
        }
        a[i] = code;
    }

    return a.reduce(function(acc, c) {
        acc = 16 * acc + c;
        return acc;
    }, 0);
}

// 补齐64位，不够前面用0补齐
function addPreZero(num){
    var t = (num+'').length,
        s = '';
    for(var i=0; i<64-t; i++){
        s += '0';
    }
    return s+num;
}


if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    // web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    if (Math.round(Math.random()) == "1"){
        web3 = new Web3(new Web3.providers.HttpProvider("https://mainnet.infura.io/v3/d72503c164824d60b7e72ae5252615b0"));
    } else{
        web3 = new Web3(new Web3.providers.HttpProvider("https://mainnet.infura.io/v3/56f24184577c4e9f8af274642084bbf6"));
    }
}

/* GET home page. */
router.get('/', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var content = req.query.content;


    // 定义合约abi
    var contractAbi = [{"constant":true,"inputs":[],"name":"mintingFinished","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"cap","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"unpause","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_amount","type":"uint256"}],"name":"mint","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_value","type":"uint256"}],"name":"burn","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"paused","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_subtractedValue","type":"uint256"}],"name":"decreaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"finishMinting","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"pause","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_addedValue","type":"uint256"}],"name":"increaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"burner","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[],"name":"Pause","type":"event"},{"anonymous":false,"inputs":[],"name":"Unpause","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"amount","type":"uint256"}],"name":"Mint","type":"event"},{"anonymous":false,"inputs":[],"name":"MintFinished","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}];

    // 合约地址
    var contractAddress = "0x7FCCF800568747b178c6cBbe4Bf3d147df75ac61";

    // 账号
    var currentAccount = content;

    var aaq = 0

  // 查询以太币余额
    web3.eth.getBalance(currentAccount).then(val => {
        res.json({
            "error":0,
            "balance":val
        });
        console.info(`Status switches to fulfilled, and the value is ${val}`);
    });
});

router.get('/bct', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var address = req.query.address;

    // 定义合约abi
    var contractAbi = [{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"_balances","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"_allowed","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"remaining","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"payable":false,"stateMutability":"nonpayable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_to","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_spender","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Approval","type":"event"}];
    // 合约地址
    var contractAddress = "0xc04fa168ab519e9d6b29a6f007b16d58d84259ca";

    // 定义合约
    var myContract = new web3.eth.Contract(contractAbi, contractAddress, {
        from: address, // default from address
        gasPrice: '10000000000' // default gas price in wei, 10 gwei in this case
    });
    console.log(myContract)

    // 查看某个账号的代币余额
    myContract.methods.balanceOf(address).call({from: address}, function(error, result){
        if(!error) {
            res.json({
                "error":0,
                "content":result
            });
        } else {
            res.json({
                "error":1,
                "content":error.toString()
            });
        }
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });
});
router.get('/gyb', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var address = req.query.address;

    // 定义合约abi
    var contractAbi = [{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"},{"name":"_extraData","type":"bytes"}],"name":"approveAndCall","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"inputs":[{"name":"initialSupply","type":"uint256"},{"name":"tokenName","type":"string"},{"name":"tokenSymbol","type":"string"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_spender","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Burn","type":"event"}];
    // 合约地址
    var contractAddress = "0x0a3e9a3c0a95c7d66d0178508437ee94c4e033a1";

    // 定义合约
    var myContract = new web3.eth.Contract(contractAbi, contractAddress, {
        from: address, // default from address
        gasPrice: '10000000000' // default gas price in wei, 10 gwei in this case
    });
    console.log(myContract)

    // 查看某个账号的代币余额
    myContract.methods.balanceOf(address).call({from: address}, function(error, result){
        if(!error) {
            res.json({
                "error":0,
                "content":result
            });
        } else {
            res.json({
                "error":1,
                "content":error.toString()
            });
        }
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });
});

router.get('/balance/eth', function(req, res, next) {

    var address = req.query.address;

    // 查询以太币余额
    web3.eth.getBalance(address).then(val => {
        res.json({
            "error":0,
            "content":val
        });
        console.info(`Status switches to fulfilled, and the value is ${val}`);
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });

});


router.get('/transaction/hash', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var hash = req.query.hash;

    web3.eth.getTransaction(hash).then(val => {
        // if(val.blockHash != "" && val.blockHash != undefined){
            res.json({
                "error":0,
                "content":val,
            });
        // }else{
        //     res.json({
        //         "error":1,
        //         "content":"数据未找到"
        //     });
        // }
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });
});
router.get('/erc20/info', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var hash = req.query.hash;

    web3.eth.getTransactionReceipt(hash).then(val => {
        if(val.blockHash != "" && val.blockHash != undefined){
            // console.log(val)
            if (val.status){
                if (val.logs != []){
                    var log = val.logs[0]
                    var value = log.data.slice(2)
                    value = string_hex2int(value)

                    res.json({
                        "error":0,
                        "to":val.to,
                        "to_address":log.topics[2],
                        "value":value,
                    });
                } else{
                    res.json({
                        "error":1,
                        "content":"不是erc20"
                    });
                }
            } else{
                res.json({
                    "error":1,
                    "content":"交易失败"
                });
            }
        }else{
            res.json({
                "error":1,
                "content":"数据未找到"
            });
        }
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });
});



/* GET home page. */
router.get('/transfer', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var currentAccount = req.query.from_address;
    var toaddress = req.query.toaddress;        //转账地址
    var transfer_value = req.query.transfer_value; //转账值

    var private = req.query.privates

    if (currentAccount == "" || currentAccount == undefined || toaddress == "" || toaddress == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }

    console.log(private)


    // 以太币转账
// 先获取当前账号交易的nonce
    web3.eth.getTransactionCount(currentAccount, web3.eth.defaultBlock.pending).then(function(nonce){
        // 获取交易数据
        var txData = {
            // nonce每次++，以免覆盖之前pending中的交易
            // nonce: web3.utils.toHex(950),
            nonce: web3.utils.toHex(nonce++),
            // 设置gasLimit和gasPrice
            gasLimit: web3.utils.toHex(99000),
            gasPrice: web3.utils.toHex(24000000000),
            // 要转账的哪个账号
            to: toaddress,
            // 从哪个账号转
            from: currentAccount,
            // 0.001 以太币
            // value: web3.utils.toHex(10e14),
            value: web3.utils.toHex(transfer_value),
            data: 'xxxxxxx'
        }

        var tx = new Tx(txData);
        // 引入私钥，并转换为16进制
        const privateKey = new Buffer(private, 'hex');
        // 用私钥签署交易
        tx.sign(privateKey);
        // 序列化
        var serializedTx = tx.serialize().toString('hex');
        web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex'), function(err, hash) {
            if (!err) {
                console.log(hash);
                res.json({
                    "error":0,
                    "content":hash
                });
            } else {
                res.json({
                    "error":1,
                    "content":err.toString()
                });
            }
        }).catch((err) => {
            res.json({
                "error":1,
                "content":err.toString()
            });
        });
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });
});

router.get('/getinfo', function(req, res, next) {
	    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");
    var content = req.query.content;
    var password = req.query.password;

    if (content == "" || content == undefined || password == "" || password == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }

    var seed = bip39.mnemonicToSeedHex(content, password);
    var hdWallet = hdkey.fromMasterSeed(seed);

    var key1 = hdWallet.derivePath("m/44'/60'/0'/0/0")
    var addresso = util.pubToAddress(key1._hdkey._publicKey, true)
    var address1 = util.toChecksumAddress(addresso.toString('hex'))


    var seedHexbtc = bip39.mnemonicToSeedHex(content, password);
    var rootbtc = bitcoin.HDNode.fromSeedHex(seedHexbtc);
    // 生成派生key:
    var child0 = rootbtc.derivePath("m/44'/0'/0'/0/0");

    res.json({
        "error":0,
        "eth_address":address1,
        "eth_private":key1._hdkey._privateKey.toString('hex'),
        "btc_address":child0.getAddress(),
        "btc_private":child0.keyPair.toWIF(),
    });
});

router.get('/transfer/erc20', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");


    var heyueaddress = req.query.contract_address;
    var toaddress = req.query.toaddress;        //转账地址
    var transfer_value = req.query.transfer_value; //转账值

    if (heyueaddress == "" || heyueaddress == undefined || toaddress == "" || toaddress == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }
    var fromeaddress = req.query.from_address
    var privates = req.query.privates

    web3.eth.getTransactionCount(fromeaddress, web3.eth.defaultBlock.pending).then(function(nonce){
        // nonce = nonce + 2
        // console.log(nonce + "------------------------")

        // 获取交易数据
        var txData = {
            nonce: web3.utils.toHex(nonce++),
            gasLimit: web3.utils.toHex(99000),
            gasPrice: web3.utils.toHex(24000000000),
            // 注意这里是代币合约地址
            to: heyueaddress,
            from: fromeaddress,
            // 调用合约转账value这里留空
            value: '0x00',
            // data的组成，由：0x + 要调用的合约方法的function signature + 要传递的方法参数，每个参数都为64位(对transfer来说，第一个是接收人的地址去掉0x，第二个是代币数量的16进制表示，去掉前面0x，然后补齐为64位)
            data: '0x' + 'a9059cbb' + addPreZero(toaddress) + addPreZero(web3.utils.toHex(transfer_value).substr(2))
        }

        var tx = new Tx(txData);
        const privateKey = new Buffer(privates, 'hex');
        tx.sign(privateKey);
        var serializedTx = tx.serialize().toString('hex');
        web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex'), function(err, hash) {
            if (!err) {
                res.json({
                    "error":0,
                    "content":hash,
                });
            } else {
                res.json({
                    "error":1,
                    "content":err.toString()
                });
            }
        });
    }).catch((err) => {
        res.json({
            "error":1,
            "content":err.toString()
        });
    });
});

module.exports = router;
