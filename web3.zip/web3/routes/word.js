var express = require('express');
var router = express.Router();
const bip39 = require('bip39');
const bip32 = require('bip32');
const bitcoin = require('bitcoinjs-lib');

var hdkey = require('ethereumjs-wallet/hdkey')
var util = require('ethereumjs-util')

router.get('/english', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var words = bip39.generateMnemonic(128);

    res.json({
        "error":0,
        "content":words
    });
});
router.get('/chinese', function(req, res, next) {

    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var words = bip39.generateMnemonic(256, null, bip39.wordlists.chinese_simplified);
    res.json({"error":"0","content":words});
});
router.get('/chinesenew', function(req, res, next) {

    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var words = bip39.generateMnemonic(128, null, bip39.wordlists.chinese_simplified);
    res.json({"error":"0","content":words});
});
//根据私钥获取地址
router.get('/private/account', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");
    var privates = req.query.privates;
    if (privates == "" || privates == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }

    try {
        var data = web3.eth.accounts.privateKeyToAccount(privates);
        res.json({
            "error":0,
            "content":data.address
        });
    }catch(err){
        res.json({
            "error":1,
            "content":err.toString()
        });
    }
});

router.get('/getaddresss', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var content = "锐 独 诚 翼 苯 上 务 号 紧 来 绘 营";
    var password = req.query.password;
    var user_id = req.query.user_id;

    if (content == "" || content == undefined || password == "" || password == undefined || user_id == "" || user_id == undefined){
        res.json({"error":1,"content":"参数错误哦"});
        return false;
    }

    var seed = bip39.mnemonicToSeedHex(content, password);
    var hdWallet = hdkey.fromMasterSeed(seed);

    var key1 = hdWallet.derivePath("m/44'/60'/0'/0/"+user_id)
    var addresso = util.pubToAddress(key1._hdkey._publicKey, true)
    var address1 = util.toChecksumAddress(addresso.toString('hex'))

    var seedHexbtc = bip39.mnemonicToSeedHex(content, password);
    var rootbtc = bitcoin.HDNode.fromSeedHex(seedHexbtc);
    // 生成派生key:
    var child0 = rootbtc.derivePath("m/44'/0'/0'/0/"+user_id);


    var content_two = "货 价 栽 棉 走 驱 霍 扰 员 步 咬 峡";
    var seed_two = bip39.mnemonicToSeedHex(content_two, password);
    var hdWallet_two = hdkey.fromMasterSeed(seed_two);
    var key2 = hdWallet_two.derivePath("m/44'/60'/0'/0/"+user_id)
    var addresso2 = util.pubToAddress(key2._hdkey._publicKey, true)
    var address2 = util.toChecksumAddress(addresso2.toString('hex'))

    var seedHexbtc2 = bip39.mnemonicToSeedHex(content_two, password);
    var rootbtc2 = bitcoin.HDNode.fromSeedHex(seedHexbtc2);
    var child2 = rootbtc2.derivePath("m/44'/0'/0'/0/"+user_id);

    res.json({
        "error":0,
        "eth_address":address1,
        "eth_private":key1._hdkey._privateKey.toString('hex'),
        "erc20_address":address2,
        "erc20_private":key2._hdkey._privateKey.toString('hex'),
        "btc_address":child0.getAddress(),
        "btc_private":child0.keyPair.toWIF(),
        "usdt_address":child2.getAddress(),
        "usdt_private":child2.keyPair.toWIF(),
    });
});



router.get('/generateeth', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var content = req.query.content;

    if (content == "" || content == undefined ){
        res.json({"error":1,"content":"参数错误"});
        return false;
    }

    var seed = bip39.mnemonicToSeedHex(content);
    var hdWallet = hdkey.fromMasterSeed(seed);

    var key1 = hdWallet.derivePath("m/44'/60'/0'/0/0")
    var addresso = util.pubToAddress(key1._hdkey._publicKey, true)
    var address1 = util.toChecksumAddress(addresso.toString('hex'))


    res.json({
        "error":0,
        "address":address1,
        "private":key1._hdkey._privateKey.toString('hex'),
    });
});

router.get('/getinfobyhash', function(req, res, next) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Origin", "*");

    var hash = req.query.hash;

    if (hash == "" || hash == undefined ){
        res.json({"error":1,"content":"参数错误"});
        return false;
    }

    var seed = bip39.mnemonicToSeedHex(content);
    var hdWallet = hdkey.fromMasterSeed(seed);

    var key1 = hdWallet.derivePath("m/44'/60'/0'/0/0")
    var addresso = util.pubToAddress(key1._hdkey._publicKey, true)
    var address1 = util.toChecksumAddress(addresso.toString('hex'))


    res.json({
        "error":0,
        "address":address1,
        "private":key1._hdkey._privateKey.toString('hex'),
    });
});

var getIp = function(req) {
    var ip = req.headers['x-real-ip'] ||
        req.headers['x-forwarded-for'] ||
        req.socket.remoteAddress || '';
    if(ip.split(',').length>0){
        ip = ip.split(',')[0];
    }
    return ip;
};


module.exports = router;
