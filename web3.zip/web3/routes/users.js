var express = require('express');
var router = express.Router();
const bip39 = require('bip39');
const bip32 = require('bip32');
const bitcoin = require('bitcoinjs-lib');

/* GET users listing. */
router.get('/', function(req, res, next) {
    var words = bip39.generateMnemonic(256, null, bip39.wordlists.chinese_simplified);
    var clientIp = getIp(req)

    console.log("KHD IP:"+req.query.id)
    res.json({"error":0,"content":words});
});
/* GET users listing. */
router.get('/yingwen', function(req, res, next) {
    var words = bip39.generateMnemonic(256);
    console.log(words);

    res.send(words);
});

router.get('/password', function(req, res, next) {
    var words = bip39.generateMnemonic(256, null, bip39.wordlists.chinese_simplified);
    console.log(words);
    var password = 'bitcoin';
    var seedAsHex = bip39.mnemonicToSeedHex(words, password);

    var root = bitcoin.HDNode.fromSeedHex(seedAsHex);
    // var root = bip32.fromSeed(Buffer.from(seedAsHex, 'hex'))
    // var child1 = root.derivePath("m/60'/0'/0'/0/0")


    // var root = bitcoin.HDNode.fromSeedHex(seedAsHex);

    var child0 = root.derivePath("m/44'/0'/0'/0/0");

    console.log("prv m/0'/0'/0'/0/0: " + child0.keyPair.toWIF()); // KzuPk3PXKdnd6QwLqUCK38PrXoqJfJmACzxTaa6TFKzPJR7H7AFg
    console.log("pub m/0'/0'/0'/0/0: " + child0.getAddress()); // 1PwKkrF366RdTuYsS8KWEbGxfP4bikegcS


    res.send(child0.getAddress());
});


var getIp = function(req) {
    var ip = req.headers['x-real-ip'] ||
        req.headers['x-forwarded-for'] ||
        req.socket.remoteAddress || '';
    if(ip.split(',').length>0){
        ip = ip.split(',')[0];
    }
    return ip;
};


module.exports = router;
